package modelo;

public class DescontoMaiorDoQueJurosException extends Exception {
    public DescontoMaiorDoQueJurosException(String message) {
        super(message);
    }
}
